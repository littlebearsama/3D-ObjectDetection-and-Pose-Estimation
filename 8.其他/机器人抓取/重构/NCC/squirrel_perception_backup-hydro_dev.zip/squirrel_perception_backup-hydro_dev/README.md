object_perception
=================
[![Build Status](https://magnum.travis-ci.com/squirrel-project/object_perception.svg?token=3yXoCRsCegowgzzpPuqw)](https://magnum.travis-ci.com/squirrel-project/object_perception)

Technical Maintainer: mzillich (Michael Zillich, TU Wien)

Repository for object perception related SQUIRREL packages.
