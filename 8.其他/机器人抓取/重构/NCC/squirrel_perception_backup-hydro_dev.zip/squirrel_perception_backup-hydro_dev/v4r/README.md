This is the git mirror of ACIN's v4r library.
