GraphCut
========

Graph-Cut algorithm, based on Felzenszwalb's implementation.

Requirements:
-------------


------------------
Andreas Richtsfeld
Automation and Control Institute
Vienna University of Technology
ari(at)acin.tuwien.ac.at
skype: andreas.richtsfeld

