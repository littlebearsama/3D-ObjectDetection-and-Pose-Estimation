

#include "mesh_source.h"

template class faat_pcl::rec_3d_framework::MeshSource<struct pcl::PointXYZ>;

