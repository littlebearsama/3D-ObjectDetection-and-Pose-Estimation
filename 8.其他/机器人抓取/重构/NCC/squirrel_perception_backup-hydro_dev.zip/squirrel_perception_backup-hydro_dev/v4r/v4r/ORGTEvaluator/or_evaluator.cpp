/*
 * or_evaluator.cpp
 *
 *  Created on: Mar 12, 2013
 *      Author: aitor
 */

#include "or_evaluator.hpp"

template class faat_pcl::rec_3d_framework::or_evaluator::OREvaluator<pcl::PointXYZ>;
template class faat_pcl::rec_3d_framework::or_evaluator::OREvaluator<pcl::PointXYZRGB>;
template class faat_pcl::rec_3d_framework::or_evaluator::OREvaluator<pcl::PointXYZRGBA>;
