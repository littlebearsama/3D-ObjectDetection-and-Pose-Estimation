/*
 * multi_pipeline_recognizer.cpp
 *
 *  Created on: Feb 25, 2013
 *      Author: aitor
 */

#include "multi_pipeline_recognizer.hpp"

template class PCL_EXPORTS faat_pcl::rec_3d_framework::MultiRecognitionPipeline<pcl::PointXYZ>;
template class PCL_EXPORTS faat_pcl::rec_3d_framework::MultiRecognitionPipeline<pcl::PointXYZRGB>;
