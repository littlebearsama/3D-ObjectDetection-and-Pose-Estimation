

#include "shot_local_estimator_omp.h"

template class faat_pcl::rec_3d_framework::SHOTLocalEstimationOMP<struct pcl::PointXYZ, struct pcl::Histogram<352> >; 
