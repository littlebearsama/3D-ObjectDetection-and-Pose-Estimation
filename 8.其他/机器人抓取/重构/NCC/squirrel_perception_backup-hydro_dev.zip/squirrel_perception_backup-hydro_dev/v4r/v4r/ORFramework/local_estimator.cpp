

#include "local_estimator.h"

template class faat_pcl::rec_3d_framework::LocalEstimator<struct pcl::PointXYZ, struct pcl::Histogram<352> >; 
template class faat_pcl::rec_3d_framework::UniformSamplingExtractor<struct pcl::PointXYZ>; 
